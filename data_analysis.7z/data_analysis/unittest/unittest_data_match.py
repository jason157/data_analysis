import unittest
from src.data_match import main

class DataMatchTestCase(unittest.TestCase):
    def test_main(self):
        print("start testing!!")
        main()



if __name__ == '__main__':
    unittest.main()
